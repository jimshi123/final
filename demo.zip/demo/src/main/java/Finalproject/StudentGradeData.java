package Finalproject;

import java.time.LocalDate;

public class StudentGradeData extends StudentGrade {
    private double math;
    private double physics;
    private double chemistry;
    private double total;
    private double average;
    private String remark;
    private LocalDate date;

    public StudentGradeData(int id, String name, LocalDate date, double math, double physics, double chemistry, double total, double average, String remark) {
        super(id, name);
        this.date = date;
        this.math = math;
        this.physics = physics;
        this.chemistry = chemistry;
        this.total = total;
        this.average = average;
        this.remark = remark;
    }
    public String getRemark() {
        return remark;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public double getMath() {
        return math;
    }

    public void setMath(double math) {
        this.math = math;
    }

    public double getPhysics() {
        return physics;
    }

    public void setPhysics(double physics) {
        this.physics = physics;
    }

    public double getChemistry() {
        return chemistry;
    }

    public void setChemistry(double chemistry) {
        this.chemistry = chemistry;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getAverage() {
        return average;
    }

    public void setAverage(double average) {
        this.average = average;
    }


    public void setRemark(String remark) {
        this.remark = remark;
    }



}