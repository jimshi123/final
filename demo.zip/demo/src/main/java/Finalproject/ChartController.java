package Finalproject;


import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import java.util.ArrayList;
import java.util.List;

public class ChartController {

    @FXML
    private BarChart<String, Number> barChart;

    private ObservableList<StudentGrade> allStudentGrades;

    public void initialize() {
        // Initialize the bar chart, set labels, titles, etc.
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Subject");

        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Score");

        barChart.setTitle("Student Performance Statistics");
        barChart.setLegendVisible(true);

        barChart.setCategoryGap(20);

        barChart.getXAxis().setTickLabelsVisible(true);
        barChart.getYAxis().setTickLabelsVisible(true);
    }

    public void displayStatistics(StudentGradeData selectedStudent, String selectedRemark) {
        // Calculate mean and median for math, physics, and chemistry
        List<Double> mathScores = new ArrayList<>();
        List<Double> physicsScores = new ArrayList<>();
        List<Double> chemistryScores = new ArrayList<>();

        for (StudentGrade grade : allStudentGrades) {
            if (grade instanceof StudentGradeData) {
                StudentGradeData studentGrade = (StudentGradeData) grade;
                if (studentGrade.getRemark().equals(selectedRemark)) {
                    mathScores.add(studentGrade.getMath());
                    physicsScores.add(studentGrade.getPhysics());
                    chemistryScores.add(studentGrade.getChemistry());
                }
            }
        }

        double mathMean = calculateMean(mathScores);
        double mathMedian = calculateMedian(mathScores);
        double physicsMean = calculateMean(physicsScores);
        double physicsMedian = calculateMedian(physicsScores);
        double chemistryMean = calculateMean(chemistryScores);
        double chemistryMedian = calculateMedian(chemistryScores);

        // Display data in the bar chart
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Student Performance");

        series.getData().add(new XYChart.Data<>("Math", selectedStudent.getMath()));
        series.getData().add(new XYChart.Data<>("Mean of Math", mathMean));
        series.getData().add(new XYChart.Data<>("Median of Math", mathMedian));

        series.getData().add(new XYChart.Data<>("Physics", selectedStudent.getPhysics()));
        series.getData().add(new XYChart.Data<>("Mean of Physics", physicsMean));
        series.getData().add(new XYChart.Data<>("Median of Physics", physicsMedian));

        series.getData().add(new XYChart.Data<>("Chemistry", selectedStudent.getChemistry()));
        series.getData().add(new XYChart.Data<>("Mean of Chemistry", chemistryMean));
        series.getData().add(new XYChart.Data<>("Median of Chemistry", chemistryMedian));

        barChart.getData().add(series);
    }

    private double calculateMean(List<Double> scores) {
        double sum = 0;
        for (double score : scores) {
            sum += score;
        }
        return sum / scores.size();
    }

    private double calculateMedian(List<Double> scores) {
        scores.sort(Double::compareTo);
        int size = scores.size();
        if (size % 2 == 0) {
            return (scores.get(size / 2 - 1) + scores.get(size / 2)) / 2.0;
        } else {
            return scores.get(size / 2);
        }
    }

    public void setAllStudentGrades(ObservableList<StudentGrade> allStudentGrades) {
        this.allStudentGrades = allStudentGrades;
    }
}


