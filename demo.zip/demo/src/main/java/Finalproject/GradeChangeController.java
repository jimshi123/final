package Finalproject;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.collections.ObservableList;
import javafx.util.converter.DoubleStringConverter;
import java.time.LocalDate;

public class GradeChangeController {

    @FXML
    private TextField nameTextField;
    @FXML
    private TextField mathTextField;
    @FXML
    private TextField physicsTextField;
    @FXML
    private TextField chemistryTextField;
    @FXML
    private TextField remarkTextField;
    @FXML
    private TextField dateTextField;
    @FXML
    private Label totalLabel;
    @FXML
    private Label averageLabel;
    @FXML
    private TextField idTextField;
    @FXML
    private Label idLabel;

    @FXML
    private Label nameLabel;

    private StudentGradeData selectedStudentGrade;

    private ObservableList<StudentGrade> modifiedData;

    private MainController mainController;
    private StudentGradeData initialStudentGrade;
    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }

    @FXML
    public void onAddButtonClick() {
        double math = new DoubleStringConverter().fromString(mathTextField.getText());
        double physics = new DoubleStringConverter().fromString(physicsTextField.getText());
        double chemistry = new DoubleStringConverter().fromString(chemistryTextField.getText());

        double total = math + physics + chemistry;
        double average = total / 3.0;

        int id = Integer.parseInt(idTextField.getText());
        StudentGradeData newStudentGrade = new StudentGradeData(id, nameTextField.getText(),
                LocalDate.parse(dateTextField.getText()), math, physics, chemistry, total, average, remarkTextField.getText());


        modifiedData.add(newStudentGrade);





    }

    public void setModifiedData(ObservableList<StudentGrade> modifiedData) {
        this.modifiedData = modifiedData;
    }
    @FXML
    public void onReplaceButtonClick() {

        double math = Double.parseDouble(mathTextField.getText());
        double physics = Double.parseDouble(physicsTextField.getText());
        double chemistry = Double.parseDouble(chemistryTextField.getText());

        double total = math + physics + chemistry;
        double average = total / 3.0;

        selectedStudentGrade.setMath(math);
        selectedStudentGrade.setPhysics(physics);
        selectedStudentGrade.setChemistry(chemistry);
        selectedStudentGrade.setTotal(total);
        selectedStudentGrade.setAverage(average);
        selectedStudentGrade.setRemark(remarkTextField.getText());

        totalLabel.setText(Double.toString(total));
        averageLabel.setText(Double.toString(average));



    }


    @FXML
    public void onSaveAndReturnButtonClick() {

        if (modifiedData != null) {
            int index = modifiedData.indexOf(selectedStudentGrade);
            if (index != -1) {
                modifiedData.set(index, selectedStudentGrade);
            }
        }

        Stage stage = (Stage) totalLabel.getScene().getWindow();
        stage.close();



    }
    public void setSelectedStudentGrade(StudentGradeData selectedStudentGrade) {
        this.selectedStudentGrade = selectedStudentGrade;


        idLabel.setText(Integer.toString(selectedStudentGrade.getId()));
        nameLabel.setText(selectedStudentGrade.getName());
        mathTextField.setText(Double.toString(selectedStudentGrade.getMath()));
        physicsTextField.setText(Double.toString(selectedStudentGrade.getPhysics()));
        chemistryTextField.setText(Double.toString(selectedStudentGrade.getChemistry()));
        remarkTextField.setText(selectedStudentGrade.getRemark());
        totalLabel.setText(Double.toString(selectedStudentGrade.getTotal()));
        averageLabel.setText(Double.toString(selectedStudentGrade.getAverage()));
    }
}
