package Finalproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class SearchController {

    @FXML
    private TextField searchField;

    @FXML
    private Button searchButton;

    private MainController mainController;

    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }

    @FXML
    public void onSearchButtonClick(ActionEvent event) {
        String searchText = searchField.getText().trim(); // Get the search text from the TextField

        if (!searchText.isEmpty()) {
            int searchID;
            try {
                searchID = Integer.parseInt(searchText); // Parse the input to an integer
            } catch (NumberFormatException e) {
                displaySearchError("Please enter a valid ID."); // Display error for invalid input
                return;
            }


            mainController.getStudentGrades().removeIf(studentGrade -> studentGrade.getId() != searchID);

            if (mainController.getStudentGrades().isEmpty()) {
                displaySearchError("No student found with this ID.");
            }
        } else {
            displaySearchError("Please enter an ID to search.");
        }
    }

    private void displaySearchError(String errorMessage) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Search Error");
        alert.setHeaderText(null);
        alert.setContentText(errorMessage);
        alert.showAndWait();
    }
}
