package Finalproject;

import java.nio.file.Files;
import java.nio.file.Paths;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.io.BufferedReader;
import java.io.IOException;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import java.time.LocalDate;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;
import javafx.scene.control.Label;
import java.util.Stack;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;




public class MainController {

    @FXML
    private TableView<StudentGrade> gradetable;
    @FXML
    private TableColumn<StudentGrade, Integer> numcol;
    @FXML
    private TableColumn<StudentGrade, String> namecol;
    @FXML
    private TableColumn<StudentGrade, Double> math;
    @FXML
    private TableColumn<StudentGrade, Double> physics;
    @FXML
    private TableColumn<StudentGrade, Double> chemistry;
    @FXML
    private TableColumn<StudentGrade, String> remark;
    @FXML
    private TableColumn<StudentGrade, Double> sum;
    @FXML
    private TableColumn<StudentGrade, Double> average;
    @FXML
    private TableColumn<StudentGrade, LocalDate> date;
    @FXML
    private Label nameLabel;
    @FXML
    private Label idLabel;
    @FXML
    private Label ageLabel;
    private String loggedInName;
    private int loggedInID;
    private int loggedInAge;
    private String userType;
    @FXML
    private Button showBtn;
    @FXML
    private Button exitBtn;
    @FXML
    private Button changeGradeButton;
    @FXML
    private Button addButton;
    @FXML
    private Button deleteButton;
    @FXML
    private Button saveButton;
    @FXML
    private Button chartButton;



    private ObservableList<StudentGrade> studentGrades = FXCollections.observableArrayList();

    private Stack<ObservableList<StudentGrade>> historyStack = new Stack<>();
    public ObservableList<StudentGrade> getStudentGrades() {
        return studentGrades;
    }

    @FXML
    public void onReturnButtonClick(ActionEvent event) {
        if (!historyStack.isEmpty()) {
            ObservableList<StudentGrade> previousState = historyStack.pop();
            studentGrades.setAll(previousState);
        }
    }
    public void setUserType(String userType) {
        this.userType = userType;


        if ("Student".equals(userType)) {

            changeGradeButton.setVisible(false);
            addButton.setVisible(false);
            deleteButton.setVisible(false);
            saveButton.setVisible(false);

            ObservableList<StudentGrade> filteredGrades = FXCollections.observableArrayList();
            for (StudentGrade grade : studentGrades) {
                if (grade.getId() == loggedInID) {
                    filteredGrades.add(grade);
                }
            }
            gradetable.setItems(filteredGrades);
        } else {

            changeGradeButton.setVisible(true);
            addButton.setVisible(true);
            deleteButton.setVisible(true);
            saveButton.setVisible(true);

            gradetable.setItems(studentGrades);
        }
    }


    @FXML
    public void initialize() {
        numcol.setCellValueFactory(new PropertyValueFactory<>("id"));
        namecol.setCellValueFactory(new PropertyValueFactory<>("name"));
        math.setCellValueFactory(new PropertyValueFactory<>("math"));
        physics.setCellValueFactory(new PropertyValueFactory<>("physics"));
        chemistry.setCellValueFactory(new PropertyValueFactory<>("chemistry"));
        sum.setCellValueFactory(new PropertyValueFactory<>("total"));
        average.setCellValueFactory(new PropertyValueFactory<>("average"));
        remark.setCellValueFactory(new PropertyValueFactory<>("remark"));
        date.setCellValueFactory(new PropertyValueFactory<>("date"));

        gradetable.setItems(studentGrades); // Set table items to studentGrades
        storeCurrentState(); // Store initial state
    }

    @FXML
    public void onshowclick(ActionEvent event) {
        loadDataFromCSV();
    }

    @FXML
    public void onexitclick(ActionEvent event) {
        Button btn = (Button) event.getSource();
        Stage stage = (Stage) btn.getScene().getWindow();
        stage.close();
    }

    @FXML
    public void onChangeGradeClick(ActionEvent event) {
        StudentGradeData selectedStudentGrade = (StudentGradeData) gradetable.getSelectionModel().getSelectedItem();
        if (selectedStudentGrade != null) {
            storeCurrentState(); // Store state before changing grade

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("gradechange.fxml"));
                Parent root = loader.load();
                GradeChangeController gradeChangeController = loader.getController();
                gradeChangeController.setModifiedData(studentGrades);
                gradeChangeController.setSelectedStudentGrade((StudentGradeData) selectedStudentGrade);

                Stage stage = new Stage();
                stage.setTitle("Grade Change");
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException | NullPointerException e) {
                e.printStackTrace();
            }
        }
        storeCurrentState();
    }



    @FXML
    public void onAddButtonClick(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("gradeadd.fxml"));
            Parent root = loader.load();
            GradeChangeController gradeChangeController = loader.getController();
            gradeChangeController.setModifiedData(studentGrades);

            Stage stage = new Stage();
            stage.setTitle("Grade Add");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
        }
        storeCurrentState();
    }

    private void loadDataFromCSV() {
        String csvFile = "C:/Users/MR/IdeaProjects/demo/src/main/java/Finalproject/studentdata.csv";
        String line;
        String cvsSplitBy = ",";

        try (BufferedReader br = Files.newBufferedReader(Paths.get(csvFile))) {
            studentGrades.clear();
            while ((line = br.readLine()) != null) {
                String[] data = line.split(cvsSplitBy);
                int id = Integer.parseInt(data[0]);
                String name = data[1];
                double mathGrade = Double.parseDouble(data[3]);
                double physicsGrade = Double.parseDouble(data[4]);
                double chemistryGrade = Double.parseDouble(data[5]);
                double total = Double.parseDouble(data[6]);
                double average = Double.parseDouble(data[7]);
                LocalDate date = LocalDate.parse(data[2]);
                String remark = data[8];


                if (userType.equals("Student") && id == loggedInID) {
                    StudentGrade studentGrade = new StudentGradeData(id, name, date, mathGrade, physicsGrade, chemistryGrade, total, average, remark);
                    studentGrades.add(studentGrade);
                } else if (userType.equals("Teacher")) {
                    StudentGrade studentGrade = new StudentGradeData(id, name, date, mathGrade, physicsGrade, chemistryGrade, total, average, remark);
                    studentGrades.add(studentGrade);
                }
            }
            gradetable.setItems(studentGrades);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @FXML
    public void onDeleteButtonClick(ActionEvent event) {
        StudentGrade selectedStudentGrade = gradetable.getSelectionModel().getSelectedItem();
        if (selectedStudentGrade != null) {
            storeCurrentState(); // Store state before deletion
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirm Deletion");
            alert.setHeaderText("Are you sure you want to delete this record?");
            alert.setContentText("Click OK to delete or Cancel to cancel.");

            ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);

            if (result == ButtonType.OK) {
                studentGrades.remove(selectedStudentGrade);
            }
        }
    }


    @FXML
    public void onSaveButtonClick(ActionEvent event) {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Save");
        alert.setHeaderText("Are you sure you want to save changes?");
        alert.setContentText("Click OK to save or Cancel to cancel.");

        ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);

        if (result == ButtonType.OK) {
            saveDataToCSV();

        }
    }

    private void saveDataToCSV() {
        try (PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("C:/Users/MR/IdeaProjects/demo/src/main/java/Finalproject/studentdata.csv")))) {
            for (StudentGrade studentGrade : studentGrades) {
                if (studentGrade instanceof StudentGradeData) {
                    StudentGradeData studentGradeData = (StudentGradeData) studentGrade;
                    pw.println(
                            studentGradeData.getId() + "," +
                                    studentGradeData.getName() + "," +
                                    studentGradeData.getDate() + "," +
                                    studentGradeData.getMath() + "," +
                                    studentGradeData.getPhysics() + "," +
                                    studentGradeData.getChemistry() + "," +
                                    studentGradeData.getTotal() + "," +
                                    studentGradeData.getAverage() + "," +
                                    studentGradeData.getRemark()
                    );
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void setLoggedInUserData(String name, int id, int age) {
        loggedInName = name;
        loggedInID = id;
        loggedInAge = age;

        nameLabel.setText(loggedInName);
        idLabel.setText(String.valueOf(loggedInID));
        ageLabel.setText(String.valueOf(loggedInAge));

        loadDataFromCSV();
    }
    @FXML
    public void onModifyButtonClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Modify.fxml"));
            Parent root = loader.load();
            ModifyController modifyController = loader.getController();
            modifyController.setMainController(this);
            modifyController.setLoggedInUserData(loggedInID, loggedInName, loggedInAge);
            Stage stage = new Stage();
            stage.setTitle("Modify");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void storeCurrentState() {
        ObservableList<StudentGrade> currentState = FXCollections.observableArrayList(studentGrades);
        historyStack.push(currentState);
    }



    public void updateLabels(String newName, int newId, int newAge) {
        nameLabel.setText(newName);
        idLabel.setText(String.valueOf(newId));
        ageLabel.setText(String.valueOf(newAge));
    }

    @FXML
    public void onChartButtonClick() {
        StudentGrade selectedStudent = gradetable.getSelectionModel().getSelectedItem();
        if (selectedStudent != null && selectedStudent instanceof StudentGradeData) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("chart.fxml"));
                Parent root = loader.load();

                ChartController chartController = loader.getController();
                chartController.setAllStudentGrades(studentGrades);
                chartController.displayStatistics((StudentGradeData) selectedStudent, selectedStudent.getRemark());

                Stage stage = new Stage();
                stage.setTitle("Student Performance Chart");
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            // Handle when no student or invalid selection is made
        }
    }

    @FXML
    public void onSearchButtonClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("search.fxml"));
            Parent root = loader.load();

            SearchController searchController = loader.getController();
            searchController.setMainController(this);

            Stage stage = new Stage();
            stage.setTitle("Search");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}