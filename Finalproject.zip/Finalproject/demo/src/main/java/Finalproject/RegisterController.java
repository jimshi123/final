package Finalproject;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javafx.scene.control.Alert;
import javafx.collections.FXCollections;
import javafx.stage.Stage;


public class RegisterController {

    @FXML
    private TextField idTextField;
    @FXML
    private TextField nameTextField;
    @FXML
    private PasswordField passwordTextField;
    @FXML
    private TextField ageTextField;
    @FXML
    private ComboBox<String> typeComboBox;

    @FXML
    private void initialize() {
        typeComboBox.setItems(FXCollections.observableArrayList("Student", "Teacher"));
        typeComboBox.getSelectionModel().select(0);
    }

    @FXML
    private void onRegisterButtonClick() {
        String id = idTextField.getText();
        String name = nameTextField.getText();
        String password = passwordTextField.getText();
        String age = ageTextField.getText();
        String type = typeComboBox.getValue();

        if (id.isEmpty() || name.isEmpty() || password.isEmpty() || age.isEmpty() || type == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Registration Error");
            alert.setHeaderText(null);
            alert.setContentText("Please fill in all the fields.");
            alert.showAndWait();
            return;
        }

        String csvFile = "C:/Users/MR/IdeaProjects/demo/src/main/java/Finalproject/Userdata.csv";
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(csvFile, true))) {
            bw.write(id + "," + name + "," + password + "," + age + "," + type);
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Registration Error");
            alert.setHeaderText(null);
            alert.setContentText("Failed to register. Please try again later.");
            alert.showAndWait();
            return;
        }


        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Registration Success");
        alert.setHeaderText(null);
        alert.setContentText("User registered successfully.");
        alert.showAndWait();

        Stage stage = (Stage) idTextField.getScene().getWindow();
        stage.close();
    }
}

