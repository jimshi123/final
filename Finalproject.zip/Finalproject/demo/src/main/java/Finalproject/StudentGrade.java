package Finalproject;

public abstract class StudentGrade {
    private int id;
    private String name;
    public StudentGrade(int id, String name) {
        this.id = id;
        this.name = name;
    }
    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public abstract String getRemark();
}