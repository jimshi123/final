package Finalproject;


import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert.AlertType;




public class LoginController {

    @FXML
    private TextField idTextField;
    @FXML
    private PasswordField passwordTextField;
    @FXML
    private ComboBox<String> typeComboBox;

    private String loggedInName;
    private int loggedInID;
    private int loggedInAge;
    private Main mainApp;
    private String userType;

    @FXML
    private void initialize() {

        typeComboBox.getItems().addAll("Teacher", "Student");
        typeComboBox.getSelectionModel().select(0);
    }

    @FXML
    private void onLoginButtonClick() {
        String id = idTextField.getText();
        String password = passwordTextField.getText();
        String type = typeComboBox.getValue();


        if (isUserValid(id, password, type)) {

            findUserData(id, type);

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("Main.fxml"));
                Parent root = loader.load();
                MainController mainController = loader.getController();

                mainController.setUserType(type);

                mainController.setLoggedInUserData(loggedInName, loggedInID, loggedInAge);

                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.setTitle("Student Performance Information Management System");
                stage.setScene(scene);
                stage.show();
                ((Stage) idTextField.getScene().getWindow()).close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Login Error");
            alert.setHeaderText(null);
            alert.setContentText("Invalid ID, Password, or Type");
            alert.showAndWait();
        }
    }

    private boolean isUserValid(String id, String password, String type) {
        String csvFile = "C:/Users/MR/IdeaProjects/demo/src/main/java/Finalproject/Userdata.csv";
        String line;
        String cvsSplitBy = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            while ((line = br.readLine()) != null) {
                String[] data = line.split(cvsSplitBy);
                String storedId = data[0];
                String storedPassword = data[2];
                String storedType = data[4];

                if (id.equals(storedId) && password.equals(storedPassword) && type.equals(storedType)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    @FXML
    private void onRegisterButtonClick() {

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("register.fxml"));
            Pane root = loader.load();
            RegisterController registerController = loader.getController();


            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("User Registration");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void findUserData(String id, String type) {
        String csvFile = "C:/Users/MR/IdeaProjects/demo/src/main/java/Finalproject/Userdata.csv";
        String line;
        String cvsSplitBy = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            while ((line = br.readLine()) != null) {
                String[] data = line.split(cvsSplitBy);
                String storedId = data[0];
                String storedName = data[1];
                int storedAge = Integer.parseInt(data[3]);
                String storedType = data[4];

                if (id.equals(storedId) && type.equals(storedType)) {
                    loggedInName = storedName;
                    loggedInID = Integer.parseInt(storedId);
                    loggedInAge = storedAge;
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void setMainApp(Main mainApp) {
        this.mainApp = mainApp;
    }
}

