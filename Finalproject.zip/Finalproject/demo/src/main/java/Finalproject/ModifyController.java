package Finalproject;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.*;

public class ModifyController {

    @FXML
    private TextField nameTextField;
    @FXML
    private TextField ageTextField;
    @FXML
    private PasswordField newPasswordField;
    @FXML
    private Button confirmButton;
    @FXML
    private Label idLabel;
    @FXML
    private Label nameLabel;
    @FXML
    private Label ageLabel;
    private int loggedInID;
    private String loggedInName;
    private int loggedInAge;
    private String loggedInPassword;
    private MainController mainController;

    public void initialize() {
        idLabel.setText(String.valueOf(loggedInID));
        nameLabel.setText(loggedInName);
        ageLabel.setText(String.valueOf(loggedInAge));

    }


    @FXML
    public void onConfirmButtonClick() {
        String newName = nameTextField.getText();
        String newAge = ageTextField.getText();
        String newPassword = newPasswordField.getText();

        if (!newName.isEmpty()) {
            loggedInName = newName;
        }
        if (!newAge.isEmpty()) {
            loggedInAge = Integer.parseInt(newAge);
        }
        if (!newPassword.isEmpty()) {
            loggedInPassword = newPassword;
        }

        saveUserDataToCSV();

        closeWindow();

        if (mainController != null) {
            mainController.updateLabels(loggedInName, loggedInID, loggedInAge);
        }
    }



    private void saveUserDataToCSV() {
        String csvFile = "C:/Users/MR/IdeaProjects/demo/src/main/java/Finalproject/Userdata.csv";
        String line;
        String cvsSplitBy = ",";
        StringBuilder newUserData = new StringBuilder();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            while ((line = br.readLine()) != null) {
                String[] data = line.split(cvsSplitBy);
                int id = Integer.parseInt(data[0]);

                if (id == loggedInID) {
                    data[1] = loggedInName;
                    data[3] = String.valueOf(loggedInAge);
                    data[2] = loggedInPassword;
                }
                newUserData.append(String.join(",", data)).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(csvFile)))) {
            pw.write(newUserData.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void closeWindow() {
        Stage stage = (Stage) confirmButton.getScene().getWindow();
        stage.close();
    }

    public void setLoggedInUserData(int id, String name, int age) {
        loggedInID = id;
        loggedInName = name;
        loggedInAge = age;

        idLabel.setText(String.valueOf(loggedInID));
        nameLabel.setText(loggedInName);
        ageLabel.setText(String.valueOf(loggedInAge));
    }
    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }

}
